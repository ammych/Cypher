import { TestBed } from '@angular/core/testing';

import { RootCategoriesResolver } from './root-categories.resolver';

describe('RootCategoriesResolver', () => {
  let service: RootCategoriesResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RootCategoriesResolver);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
