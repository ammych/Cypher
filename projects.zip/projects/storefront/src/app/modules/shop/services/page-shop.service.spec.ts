import { TestBed } from '@angular/core/testing';

import { PageShopService } from './page-shop.service';

describe('PageShopService', () => {
    let service: PageShopService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(PageShopService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
