import { TestBed } from '@angular/core/testing';

import { BrowserLoaderService } from './browser-loader.service';

describe('BrowserLoaderService', () => {
    let service: BrowserLoaderService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(BrowserLoaderService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
