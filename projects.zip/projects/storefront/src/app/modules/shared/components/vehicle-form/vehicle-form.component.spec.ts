import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { VehicleFormComponent } from './vehicle-form.component';

describe('VehicleFormComponent', () => {
    let component: VehicleFormComponent;
    let fixture: ComponentFixture<VehicleFormComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ VehicleFormComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(VehicleFormComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
