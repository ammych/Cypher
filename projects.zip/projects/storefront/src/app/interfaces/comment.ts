export interface Comment {
    id: number;
    author: string;
    postTitle: string;
    text: string;
    date: string;
}
