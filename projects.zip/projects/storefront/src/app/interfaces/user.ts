export interface User {
    email: string;
    phone: string;
    firstName: string;
    lastName: string;
    avatar: string;
}
