import { FakeSlidesDirective } from './fake-slides.directive';

describe('FakeSlidesDirective', () => {
    it('should create an instance', () => {
        const directive = new FakeSlidesDirective();
        expect(directive).toBeTruthy();
    });
});
