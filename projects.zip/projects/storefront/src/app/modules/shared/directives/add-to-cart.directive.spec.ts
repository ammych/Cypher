import { AddToCartDirective } from './add-to-cart.directive';

describe('AddToCartDirective', () => {
    it('should create an instance', () => {
        const directive = new AddToCartDirective();
        expect(directive).toBeTruthy();
    });
});
