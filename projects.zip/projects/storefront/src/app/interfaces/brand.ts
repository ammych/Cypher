export interface Brand {
    slug: string;
    name: string;
    image: string;
    country: string;
}
