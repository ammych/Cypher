import { TestBed } from '@angular/core/testing';

import { FakeShopApi } from './fake-shop.api';

describe('FakeShopApi', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: FakeShopApi = TestBed.get(FakeShopApi);
        expect(service).toBeTruthy();
    });
});
