import { TestBed } from '@angular/core/testing';

import { ProductsListResolver } from './products-list.resolver';

describe('ProductsListResolver', () => {
    let service: ProductsListResolver;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(ProductsListResolver);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
