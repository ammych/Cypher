import { OwlPreventClickDirective } from './owl-prevent-click.directive';

describe('OwlPreventClickDirective', () => {
    it('should create an instance', () => {
        const directive = new OwlPreventClickDirective();
        expect(directive).toBeTruthy();
    });
});
