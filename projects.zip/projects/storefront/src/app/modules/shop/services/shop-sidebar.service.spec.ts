import { TestBed } from '@angular/core/testing';

import { ShopSidebarService } from './shop-sidebar.service';

describe('ShopSidebarService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: ShopSidebarService = TestBed.get(ShopSidebarService);
        expect(service).toBeTruthy();
    });
});
