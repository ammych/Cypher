import { Directive } from '@angular/core';


@Directive({
    selector: '[appCollapseContent]',
})
export class CollapseContentDirective {
    constructor() { }
}
