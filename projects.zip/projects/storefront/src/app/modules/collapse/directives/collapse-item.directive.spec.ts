import { CollapseItemDirective } from './collapse-item.directive';

describe('CollapseItemDirective', () => {
    it('should create an instance', () => {
        const directive = new CollapseItemDirective(null, null);
        expect(directive).toBeTruthy();
    });
});
