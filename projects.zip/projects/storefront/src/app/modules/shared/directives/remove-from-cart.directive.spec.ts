import { RemoveFromCartDirective } from './remove-from-cart.directive';

describe('RemoveFromCartDirective', () => {
    it('should create an instance', () => {
        const directive = new RemoveFromCartDirective();
        expect(directive).toBeTruthy();
    });
});
