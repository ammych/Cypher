import { IsInvalidPipe } from './is-invalid.pipe';

describe('IsInvalidPipe', () => {
    it('create an instance', () => {
        const pipe = new IsInvalidPipe();
        expect(pipe).toBeTruthy();
    });
});
