import { CheckboxGroupDirective } from './checkbox-group.directive';

describe('CheckboxGroupDirective', () => {
    it('should create an instance', () => {
        const directive = new CheckboxGroupDirective();
        expect(directive).toBeTruthy();
    });
});
