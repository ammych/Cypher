import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { VehiclePickerModalComponent } from './vehicle-picker-modal.component';

describe('VehiclePickerModalComponent', () => {
    let component: VehiclePickerModalComponent;
    let fixture: ComponentFixture<VehiclePickerModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [ VehiclePickerModalComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(VehiclePickerModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
